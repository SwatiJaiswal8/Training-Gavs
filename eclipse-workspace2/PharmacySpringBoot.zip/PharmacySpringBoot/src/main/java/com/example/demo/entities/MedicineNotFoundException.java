package com.example.demo.entities;

public class MedicineNotFoundException extends Exception {
	public MedicineNotFoundException(String message) {
        super(message);
    }
}
